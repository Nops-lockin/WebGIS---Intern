
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  MapContainer,
  TileLayer,
  GeoJSON,
  Polyline,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "./index.css";

const API = "http://127.0.0.1:8000";
const OSRM_API = "https://router.project-osrm.org/route/v1/driving";

const COLORS = {
  rendah: "#22c55e",
  sedang: "#eab308",
  tinggi: "#f97316",
  sangat_tinggi: "#dc2626",
  belum: "#94a3b8",
};

function normalisasiKode(value) {
  return String(value ?? "").replace(/[^0-9]/g, "");
}

function formatAngka(value, digit = 1) {
  if (value === null || value === undefined || value === "") return "-";
  const n = Number(value);
  if (!Number.isFinite(n)) return "-";

  return n.toLocaleString("id-ID", {
    maximumFractionDigits: digit,
  });
}

function formatTanggal(value) {
  if (!value) return "-";

  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);

  return d.toLocaleString("id-ID", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function nilaiPertama(obj, keys) {
  for (const key of keys) {
    const value = obj?.[key];
    if (value !== null && value !== undefined && value !== "") {
      return value;
    }
  }
  return null;
}

function getNamaKelurahan(feature) {
  const p = feature?.properties || {};
  return (
    p.nama_kelurahan ||
    p.namobj ||
    p.NAMOBJ ||
    p.WADMKD ||
    p.nama ||
    "Kelurahan tanpa nama"
  );
}

function getKodeWilayah(feature) {
  const p = feature?.properties || {};
  return String(
    p.kode_wilayah ||
      p.kode_kelurahan ||
      p.kode ||
      p.kd_kelurahan ||
      p.KD_KEL ||
      p.KDEBPS ||
      ""
  );
}

function getIdKelurahan(feature) {
  const p = feature?.properties || {};
  return String(
    p.kelurahan_id ??
      p.id_kelurahan ??
      p.id ??
      p.OBJECTID ??
      ""
  );
}

function getKategori(item) {
  const value = String(
    item?.tingkat ??
      item?.kategori_risiko ??
      item?.tingkat_risiko ??
      item?.kategori ??
      item?.risiko ??
      "belum"
  ).toLowerCase();

  if (value.includes("sangat")) return "sangat_tinggi";
  if (value.includes("tinggi")) return "tinggi";
  if (value.includes("sedang")) return "sedang";
  if (value.includes("rendah")) return "rendah";
  return "belum";
}

function getRisikoId(id, kode, nama, dataByKelurahan) {
  if (id && dataByKelurahan.has(`id:${id}`)) {
    return dataByKelurahan.get(`id:${id}`);
  }

  const kodeNormal = normalisasiKode(kode);
  if (kodeNormal && dataByKelurahan.has(`kode:${kodeNormal}`)) {
    return dataByKelurahan.get(`kode:${kodeNormal}`);
  }

  const namaNormal = String(nama || "").trim().toLowerCase();
  if (namaNormal && dataByKelurahan.has(`nama:${namaNormal}`)) {
    return dataByKelurahan.get(`nama:${namaNormal}`);
  }

  return null;
}

function getRisikoKelurahan(feature, dataByKelurahan) {
  return getRisikoId(
    getIdKelurahan(feature),
    getKodeWilayah(feature),
    getNamaKelurahan(feature),
    dataByKelurahan
  );
}

// Menyesuaikan respons backend /api/bmkg/prakiraan/{kode_wilayah}.
function normalisasiPrakiraan(dataApi) {
  let daftar = [];

  if (Array.isArray(dataApi?.prakiraan)) {
    daftar = dataApi.prakiraan;
  } else if (Array.isArray(dataApi?.data?.prakiraan)) {
    daftar = dataApi.data.prakiraan;
  } else if (Array.isArray(dataApi?.data)) {
    daftar = dataApi.data.flatMap((kelompok) => {
      if (Array.isArray(kelompok)) return kelompok.flat(Infinity);

      if (Array.isArray(kelompok?.cuaca)) {
        return kelompok.cuaca.flat(Infinity);
      }

      return kelompok && typeof kelompok === "object"
        ? [kelompok]
        : [];
    });
  } else if (Array.isArray(dataApi?.cuaca)) {
    daftar = dataApi.cuaca.flat(Infinity);
  } else if (Array.isArray(dataApi)) {
    daftar = dataApi;
  }

  return daftar
    .filter((item) => item && typeof item === "object")
    .map((item) => ({
      ...item,
      waktu:
        item.waktu_lokal ||
        item.local_datetime ||
        item.datetime ||
        item.waktu ||
        item.utc_datetime ||
        item.tanggal ||
        item.valid_time ||
        item.time ||
        null,
      suhu:
        item.suhu_c ??
        item.suhu ??
        item.t ??
        item.temperature ??
        item.temperature_c ??
        item.t2m ??
        item.temp ??
        null,
      kelembapan:
        item.kelembapan_persen ??
        item.kelembapan ??
        item.hu ??
        item.humidity ??
        item.relative_humidity ??
        item.rh ??
        null,
      kondisi:
        item.kondisi ||
        item.parameter_tp ||
        item.weather_desc ||
        item.weather_desc_en ||
        item.weather ||
        item.weatherDesc ||
        item.deskripsi ||
        item.cuaca ||
        null,
    }))
    .sort(
      (a, b) =>
        new Date(a.waktu || 0).getTime() -
        new Date(b.waktu || 0).getTime()
    );
}

function StatCard({ title, value, color }) {
  return (
    <div className="stat-card">
      <div className="stat-title">{title}</div>
      <div className="stat-value" style={color ? { color } : undefined}>
        {value}
      </div>
    </div>
  );
}

function MapFocus({ data }) {
  const map = useMap();

  useEffect(() => {
    if (!data?.features?.length) return;

    try {
      const bounds = L.geoJSON(data).getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds, {
          padding: [20, 20],
          maxZoom: 13,
        });
      }
    } catch (err) {
      console.error("Gagal mengatur peta:", err);
    }
  }, [data, map]);

  return null;
}

function RouteFocus({ positions }) {
  const map = useMap();

  useEffect(() => {
    if (!positions || positions.length < 2) return;

    const bounds = L.latLngBounds(positions);
    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [45, 45] });
    }
  }, [positions, map]);

  return null;
}

export default function App() {
  const [geojson, setGeojson] = useState(null);
  const [hujan, setHujan] = useState([]);
  const [banjir, setBanjir] = useState([]);
  const [elevasi, setElevasi] = useState([]);

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("semua");
  const [selected, setSelected] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [prakiraan, setPrakiraan] = useState([]);
  const [loadingPrakiraan, setLoadingPrakiraan] = useState(false);
  const [errorPrakiraan, setErrorPrakiraan] = useState("");

  const [asalRute, setAsalRute] = useState("");
  const [tujuanRute, setTujuanRute] = useState("");
  const [rutePositions, setRutePositions] = useState([]);
  const [infoRute, setInfoRute] = useState(null);
  const [loadingRute, setLoadingRute] = useState(false);
  const [errorRute, setErrorRute] = useState("");

  // Memuat data kelurahan, hujan, analisis banjir, dan elevasi.
  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    const endpoints = [
      { key: "geojson", url: `${API}/api/kelurahan/geojson` },
      { key: "hujan", url: `${API}/api/hujan` },
      { key: "banjir", url: `${API}/api/banjir` },
      { key: "elevasi", url: `${API}/api/elevasi` },
    ];

    try {
      const results = await Promise.allSettled(
        endpoints.map(async (endpoint) => {
          const response = await fetch(endpoint.url);
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${endpoint.url}`);
          }

          return {
            key: endpoint.key,
            data: await response.json(),
          };
        })
      );

      const resultMap = {};

      results.forEach((result, index) => {
        if (result.status === "fulfilled") {
          resultMap[result.value.key] = result.value.data;
        } else {
          console.error(
            `Gagal memuat ${endpoints[index].key}:`,
            result.reason
          );
        }
      });

      const ambilArray = (value) => {
        if (Array.isArray(value)) return value;
        if (Array.isArray(value?.data)) return value.data;
        if (Array.isArray(value?.items)) return value.items;
        return [];
      };

      const geoData = resultMap.geojson;
      const hujanData = ambilArray(resultMap.hujan);
      const banjirData = ambilArray(resultMap.banjir);
      const elevasiData = ambilArray(resultMap.elevasi);

      if (geoData?.type === "FeatureCollection") {
        setGeojson(geoData);
      } else {
        setGeojson(null);
        setError("GeoJSON kelurahan tidak tersedia atau formatnya salah.");
      }

      setBanjir(banjirData);
      setElevasi(elevasiData);

      if (hujanData.length) {
        setHujan(hujanData);
      } else if (banjirData.length) {
        setHujan(
          banjirData
            .filter(
              (item) =>
                item.hujan_mm != null ||
                item.curah_hujan_mm != null ||
                item.nilai_mm != null
            )
            .map((item) => ({
              ...item,
              nilai_mm:
                item.hujan_mm ??
                item.curah_hujan_mm ??
                item.nilai_mm,
              waktu_pengamatan:
                item.waktu_pengamatan ??
                item.waktu_analisis ??
                item.tanggal,
              sumber: item.sumber || item.metode || "Analisis banjir",
            }))
        );
      } else {
        setHujan([]);
      }

      const gagal = results.filter((r) => r.status === "rejected");

      if (gagal.length === endpoints.length) {
        setError(
          "Backend tidak dapat dihubungi. Pastikan FastAPI berjalan di http://127.0.0.1:8000."
        );
      } else if (gagal.length) {
        setError(
          `${gagal.length} endpoint gagal dimuat. Periksa terminal backend.`
        );
      }
    } catch (err) {
      setError(err.message || "Gagal memuat data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Mengambil prakiraan langsung dari endpoint BMKG backend.
  useEffect(() => {
    const kode = selected?.kode_wilayah;

    if (!kode) {
      setPrakiraan([]);
      setErrorPrakiraan("");
      setLoadingPrakiraan(false);
      return;
    }

    const controller = new AbortController();

    async function loadPrakiraan() {
      setLoadingPrakiraan(true);
      setErrorPrakiraan("");
      setPrakiraan([]);

      try {
        const response = await fetch(
          `${API}/api/bmkg/prakiraan/${encodeURIComponent(kode)}`,
          { signal: controller.signal }
        );

        if (!response.ok) {
          throw new Error(
            `Prakiraan tidak tersedia (HTTP ${response.status}).`
          );
        }

        const data = await response.json();
        const daftar = normalisasiPrakiraan(data);

        setPrakiraan(daftar);

        if (!daftar.length) {
          console.warn("Format respons prakiraan belum dikenali:", data);
          setErrorPrakiraan(
            "Respons BMKG diterima, tetapi data prakiraan tidak ditemukan."
          );
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          setErrorPrakiraan(err.message || "Gagal memuat prakiraan.");
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoadingPrakiraan(false);
        }
      }
    }

    loadPrakiraan();
    return () => controller.abort();
  }, [selected?.kode_wilayah]);

  // Indeks risiko berdasarkan ID, kode, dan nama kelurahan.
  const riskByKelurahan = useMemo(() => {
    const map = new Map();

    banjir.forEach((item) => {
      const id = String(
        item.kelurahan_id ??
          item.id_kelurahan ??
          item.id ??
          ""
      );

      const kode = normalisasiKode(
        item.kode_wilayah ??
          item.kode_kelurahan ??
          item.kode ??
          ""
      );

      const nama = String(
        item.nama_kelurahan ??
          item.kelurahan ??
          item.nama ??
          ""
      ).trim().toLowerCase();

      const waktuBaru = new Date(
        item.waktu_analisis || item.tanggal || 0
      ).getTime();

      const existing = id ? map.get(`id:${id}`) : null;
      const waktuLama = new Date(
        existing?.waktu_analisis || existing?.tanggal || 0
      ).getTime();

      if (existing && waktuLama > waktuBaru) return;

      if (id) map.set(`id:${id}`, item);
      if (kode) map.set(`kode:${kode}`, item);
      if (nama) map.set(`nama:${nama}`, item);
    });

    return map;
  }, [banjir]);

  const elevationByKelurahan = useMemo(() => {
    const map = new Map();

    elevasi.forEach((item) => {
      const id = String(
        item.kelurahan_id ??
          item.id_kelurahan ??
          item.id ??
          ""
      );

      const kode = normalisasiKode(
        item.kode_wilayah ??
          item.kode_kelurahan ??
          item.kode ??
          ""
      );

      const nama = String(
        item.nama_kelurahan ??
          item.kelurahan ??
          item.nama ??
          ""
      ).trim().toLowerCase();

      if (id) map.set(`id:${id}`, item);
      if (kode) map.set(`kode:${kode}`, item);
      if (nama) map.set(`nama:${nama}`, item);
    });

    return map;
  }, [elevasi]);

  const elevasiTerpilih = useMemo(() => {
    if (!selected) return null;

    return getRisikoId(
      String(selected.id || ""),
      selected.kode_wilayah,
      selected.nama_kelurahan,
      elevationByKelurahan
    );
  }, [selected, elevationByKelurahan]);

  const daftarKelurahan = useMemo(() => {
    if (!geojson?.features) return [];

    return geojson.features
      .map((feature, index) => ({
        id: getIdKelurahan(feature) || `fitur-${index}`,
        nama: getNamaKelurahan(feature),
        kode_wilayah: getKodeWilayah(feature),
        feature,
      }))
      .sort((a, b) => a.nama.localeCompare(b.nama, "id"));
  }, [geojson]);

  const filteredGeojson = useMemo(() => {
    if (!geojson?.features) return null;

    const keyword = search.trim().toLowerCase();

    return {
      ...geojson,
      features: geojson.features.filter((feature) => {
        const nama = getNamaKelurahan(feature).toLowerCase();
        const kode = getKodeWilayah(feature).toLowerCase();

        if (
          keyword &&
          !nama.includes(keyword) &&
          !kode.includes(keyword)
        ) {
          return false;
        }

        if (filter === "semua") return true;

        const risiko = getRisikoKelurahan(feature, riskByKelurahan);
        const kategori = getKategori(risiko);

        if (filter === "belum") return kategori === "belum";
        if (filter === "sangat") return kategori === "sangat_tinggi";
        return kategori === filter;
      }),
    };
  }, [geojson, search, filter, riskByKelurahan]);

  const summary = useMemo(() => {
    const result = {
      total: daftarKelurahan.length,
      rendah: 0,
      sedang: 0,
      tinggi: 0,
      sangat_tinggi: 0,
      belum: 0,
    };

    daftarKelurahan.forEach((item) => {
      const risiko = getRisikoKelurahan(item.feature, riskByKelurahan);
      result[getKategori(risiko)]++;
    });

    return result;
  }, [daftarKelurahan, riskByKelurahan]);

  const latestRain = useMemo(() => {
    return [...hujan].sort((a, b) => {
      const waktuA = new Date(
        a.waktu_pengamatan ??
          a.tanggal ??
          a.waktu ??
          a.datetime ??
          0
      ).getTime();

      const waktuB = new Date(
        b.waktu_pengamatan ??
          b.tanggal ??
          b.waktu ??
          b.datetime ??
          0
      ).getTime();

      return waktuB - waktuA;
    });
  }, [hujan]);

  const featureStyle = useCallback(
    (feature) => {
      const risiko = getRisikoKelurahan(feature, riskByKelurahan);
      const kategori = getKategori(risiko);

      return {
        color: "#334155",
        weight: 1.2,
        opacity: 0.9,
        fillColor: COLORS[kategori],
        fillOpacity: kategori === "belum" ? 0.35 : 0.65,
      };
    },
    [riskByKelurahan]
  );

  const onEachFeature = useCallback(
    (feature, layer) => {
      const nama = getNamaKelurahan(feature);
      const kode = getKodeWilayah(feature);
      const id = getIdKelurahan(feature);

      const risiko = getRisikoKelurahan(feature, riskByKelurahan);

      const hujanItem = nilaiPertama(risiko, [
        "hujan_mm",
        "curah_hujan_mm",
        "nilai_mm",
        "curah_hujan",
      ]);

      const elevasiItem = getRisikoId(
        id,
        kode,
        nama,
        elevationByKelurahan
      );

      const elevasiValue = nilaiPertama(elevasiItem, [
        "elevasi_titik_m",
        "elevasi_m",
        "elevasi",
        "elevation",
      ]);

      const popup = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = nama;
      popup.appendChild(title);

      const kategoriRisiko = nilaiPertama(risiko, [
        "tingkat",
        "kategori_risiko",
        "tingkat_risiko",
        "kategori",
        "risiko",
      ]);

      [
        `Kode wilayah: ${kode || "-"}`,
        `Risiko: ${kategoriRisiko || "Belum dianalisis"}`,
        `Curah hujan: ${
          hujanItem == null ? "-" : `${formatAngka(hujanItem)} mm`
        }`,
        `Elevasi: ${
          elevasiValue == null
            ? "-"
            : `${formatAngka(elevasiValue)} m`
        }`,
      ].forEach((text) => {
        const line = document.createElement("div");
        line.textContent = text;
        popup.appendChild(line);
      });

      layer.bindPopup(popup);

      layer.on({
        click: () => {
          setSelected({
            id,
            nama_kelurahan: nama,
            kode_wilayah: kode,
            ...feature.properties,
          });
        },
        mouseover: (event) => {
          event.target.setStyle({
            weight: 3,
            color: "#0f172a",
            fillOpacity: 0.8,
          });
          event.target.bringToFront();
        },
        mouseout: (event) => {
          event.target.setStyle(featureStyle(feature));
        },
      });
    },
    [riskByKelurahan, elevationByKelurahan, featureStyle]
  );

  async function cariRute() {
    setErrorRute("");
    setRutePositions([]);
    setInfoRute(null);

    if (!asalRute || !tujuanRute) {
      setErrorRute("Pilih kelurahan asal dan tujuan terlebih dahulu.");
      return;
    }

    if (asalRute === tujuanRute) {
      setErrorRute("Kelurahan asal dan tujuan harus berbeda.");
      return;
    }

    const asal = daftarKelurahan.find((item) => item.id === asalRute);
    const tujuan = daftarKelurahan.find((item) => item.id === tujuanRute);

    if (!asal || !tujuan) {
      setErrorRute("Kelurahan asal atau tujuan tidak ditemukan.");
      return;
    }

    setLoadingRute(true);

    try {
      const boundsAsal = L.geoJSON(asal.feature).getBounds();
      const boundsTujuan = L.geoJSON(tujuan.feature).getBounds();

      if (!boundsAsal.isValid() || !boundsTujuan.isValid()) {
        throw new Error("Geometri kelurahan tidak valid.");
      }

      const a = boundsAsal.getCenter();
      const b = boundsTujuan.getCenter();

      const url =
        `${OSRM_API}/${a.lng},${a.lat};${b.lng},${b.lat}` +
        "?overview=full&geometries=geojson&steps=false";

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Layanan rute gagal (HTTP ${response.status}).`);
      }

      const data = await response.json();
      if (data.code !== "Ok" || !data.routes?.length) {
        throw new Error("Rute tidak ditemukan. Coba kelurahan lain.");
      }

      const route = data.routes[0];

      setRutePositions(
        route.geometry.coordinates.map(([lng, lat]) => [lat, lng])
      );

      setInfoRute({
        asal: asal.nama,
        tujuan: tujuan.nama,
        jarakKm: route.distance / 1000,
        durasiMenit: route.duration / 60,
      });
    } catch (err) {
      setErrorRute(
        `${err.message || "Gagal mencari rute."} Pastikan internet aktif.`
      );
    } finally {
      setLoadingRute(false);
    }
  }

  function hapusRute() {
    setRutePositions([]);
    setInfoRute(null);
    setErrorRute("");
    setAsalRute("");
    setTujuanRute("");
  }

  return (
    <div className="app">
      <header className="app-header">
        <div>
          <h1>WebGIS Risiko Banjir Makassar</h1>
          <p>
            Informasi curah hujan, elevasi, risiko banjir,
            prakiraan BMKG, dan rute perjalanan.
          </p>
        </div>

        <button
          className="refresh-button"
          onClick={loadData}
          disabled={loading}
        >
          {loading ? "Memuat..." : "Muat ulang data"}
        </button>
      </header>

      <main className="app-content">
        {error && (
          <div className="error-message" role="alert">
            {error}
          </div>
        )}

        <section className="stats-grid">
          <StatCard title="Total Kelurahan" value={summary.total} />
          <StatCard title="Risiko Rendah" value={summary.rendah} color={COLORS.rendah} />
          <StatCard title="Risiko Sedang" value={summary.sedang} color={COLORS.sedang} />
          <StatCard title="Risiko Tinggi" value={summary.tinggi} color={COLORS.tinggi} />
          <StatCard title="Risiko Sangat Tinggi" value={summary.sangat_tinggi} color={COLORS.sangat_tinggi} />
        </section>

        <section className="workspace">
          <div className="map-panel">
            <div className="map-toolbar">
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari nama atau kode kelurahan..."
                aria-label="Cari kelurahan"
              />

              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                aria-label="Filter risiko"
              >
                <option value="semua">Semua kategori</option>
                <option value="rendah">Risiko rendah</option>
                <option value="sedang">Risiko sedang</option>
                <option value="tinggi">Risiko tinggi</option>
                <option value="sangat">Risiko sangat tinggi</option>
                <option value="belum">Belum dianalisis</option>
              </select>
            </div>

            <section className="info-panel" style={{ margin: "12px 0", padding: "16px" }}>
              <h3 className="panel-heading">Tentukan Rute Perjalanan</h3>
              <p className="map-note">
                Pilih kelurahan asal dan tujuan untuk menampilkan rute jalan.
              </p>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                  gap: "12px",
                  marginTop: "12px",
                }}
              >
                <label>
                  <span style={{ display: "block", marginBottom: "6px" }}>
                    Kelurahan asal
                  </span>
                  <select
                    value={asalRute}
                    onChange={(e) => setAsalRute(e.target.value)}
                    style={{ width: "100%" }}
                  >
                    <option value="">-- Pilih asal --</option>
                    {daftarKelurahan.map((item) => (
                      <option key={`asal-${item.id}`} value={item.id}>
                        {item.nama}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <span style={{ display: "block", marginBottom: "6px" }}>
                    Kelurahan tujuan
                  </span>
                  <select
                    value={tujuanRute}
                    onChange={(e) => setTujuanRute(e.target.value)}
                    style={{ width: "100%" }}
                  >
                    <option value="">-- Pilih tujuan --</option>
                    {daftarKelurahan.map((item) => (
                      <option key={`tujuan-${item.id}`} value={item.id}>
                        {item.nama}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "12px" }}>
                <button className="refresh-button" onClick={cariRute} disabled={loadingRute}>
                  {loadingRute ? "Mencari rute..." : "Cari rute"}
                </button>
                <button type="button" onClick={hapusRute} disabled={loadingRute}>
                  Hapus rute
                </button>
              </div>

              {errorRute && (
                <p role="alert" style={{ color: "#b91c1c", marginTop: "10px" }}>
                  {errorRute}
                </p>
              )}

              {infoRute && (
                <div style={{ marginTop: "12px", padding: "12px", borderRadius: "8px", background: "#eff6ff", color: "#1e3a8a" }}>
                  <strong>{infoRute.asal} → {infoRute.tujuan}</strong>
                  <p style={{ margin: "6px 0 0" }}>
                    Jarak jalan: {formatAngka(infoRute.jarakKm, 2)} km
                  </p>
                  <p style={{ margin: "4px 0 0" }}>
                    Perkiraan waktu berkendara: {formatAngka(infoRute.durasiMenit, 0)} menit
                  </p>
                </div>
              )}

              <p className="map-note" style={{ marginTop: "10px" }}>
                Rute dihitung dari titik tengah wilayah menggunakan OSRM.
                Rute ini bukan jalur evakuasi resmi dan belum memperhitungkan
                genangan maupun penutupan jalan akibat banjir.
              </p>
            </section>

            <div className="map-frame">
              {geojson ? (
                <MapContainer
                  center={[-5.1477, 119.4327]}
                  zoom={11}
                  scrollWheelZoom
                  style={{ height: "600px", width: "100%" }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />

                  {filteredGeojson && (
                    <GeoJSON
                      key={`${search}-${filter}-${banjir.length}-${elevasi.length}`}
                      data={filteredGeojson}
                      style={featureStyle}
                      onEachFeature={onEachFeature}
                    />
                  )}

                  <MapFocus data={filteredGeojson} />

                  {rutePositions.length > 1 && (
                    <>
                      <Polyline
                        positions={rutePositions}
                        pathOptions={{ color: "#0759d6", weight: 6, opacity: 1 }}
                      />
                      <RouteFocus positions={rutePositions} />
                    </>
                  )}
                </MapContainer>
              ) : (
                <div className="empty-state">
                  {loading ? "Sedang memuat peta..." : "Data peta belum tersedia."}
                </div>
              )}
            </div>

            <div className="map-legend">
              <strong>Legenda risiko:</strong>
              {Object.entries({
                Rendah: COLORS.rendah,
                Sedang: COLORS.sedang,
                Tinggi: COLORS.tinggi,
                "Sangat tinggi": COLORS.sangat_tinggi,
                "Belum dianalisis": COLORS.belum,
              }).map(([label, color]) => (
                <span
                  key={label}
                  style={{ display: "inline-flex", alignItems: "center", gap: "6px", margin: "8px 10px 0 0" }}
                >
                  <span style={{ display: "inline-block", width: "12px", height: "12px", borderRadius: "3px", background: color }} />
                  {label}
                </span>
              ))}
            </div>
          </div>

          <aside className="sidebar">
            <section className="info-panel">
              <h3 className="panel-heading">Informasi Kelurahan</h3>

              {selected ? (
                <>
                  <h4>{selected.nama_kelurahan}</h4>
                  <p><strong>Kode wilayah:</strong> {selected.kode_wilayah || "-"}</p>

                  {(() => {
                    const risiko = getRisikoId(
                      String(selected.id || ""),
                      selected.kode_wilayah,
                      selected.nama_kelurahan,
                      riskByKelurahan
                    );

                    return (
                      <>
                        <p>
                          <strong>Kategori risiko:</strong>{" "}
                          {nilaiPertama(risiko, [
                            "tingkat",
                            "kategori_risiko",
                            "tingkat_risiko",
                            "kategori",
                            "risiko",
                          ]) || "Belum dianalisis"}
                        </p>
                        <p>
                          <strong>Curah hujan analisis:</strong>{" "}
                          {formatAngka(
                            nilaiPertama(risiko, [
                              "hujan_mm",
                              "curah_hujan_mm",
                              "nilai_mm",
                              "curah_hujan",
                            ])
                          )} mm
                        </p>
                        <p>
                          <strong>Waktu analisis:</strong>{" "}
                          {formatTanggal(risiko?.waktu_analisis || risiko?.tanggal)}
                        </p>
                      </>
                    );
                  })()}
                </>
              ) : (
                <p className="empty-state">Klik wilayah pada peta untuk melihat detail.</p>
              )}
            </section>

            <section className="info-panel">
              <h3 className="panel-heading">Prakiraan BMKG</h3>

              {!selected ? (
                <p className="empty-state">Pilih kelurahan pada peta untuk memuat prakiraan.</p>
              ) : loadingPrakiraan ? (
                <p>Memuat prakiraan...</p>
              ) : errorPrakiraan ? (
                <p style={{ color: "#b91c1c" }}>{errorPrakiraan}</p>
              ) : prakiraan.length ? (
                <div className="data-list" style={{ maxHeight: "340px", overflowY: "auto" }}>
                  {prakiraan.slice(0, 8).map((item, index) => {
                    const suhu = nilaiPertama(item, [
                      "suhu", "temperature", "t", "t2m", "temp", "suhu_c",
                    ]);
                    const kelembapan = nilaiPertama(item, [
                      "kelembapan", "humidity", "hu", "rh",
                      "relative_humidity", "humidity_percent", "kelembapan_persen",
                    ]);
                    const kondisi = nilaiPertama(item, [
                      "kondisi", "parameter_tp", "weather_desc",
                      "weather_desc_en", "weather", "weatherDesc", "deskripsi", "cuaca",
                    ]);
                    const waktu = nilaiPertama(item, [
                      "waktu", "waktu_lokal", "local_datetime",
                      "datetime", "tanggal", "valid_time", "time",
                    ]);

                    return (
                      <div
                        className="data-row"
                        key={`prakiraan-${index}`}
                        style={{ padding: "10px 0", borderBottom: "1px solid #e2e8f0" }}
                      >
                        <strong>{formatTanggal(waktu)}</strong>
                        <div>Suhu: {suhu == null ? "-" : formatAngka(suhu)} °C</div>
                        <div>Kondisi: {kondisi ?? "Tidak tersedia"}</div>
                        <div>
                          Kelembapan: {kelembapan == null ? "-" : formatAngka(kelembapan, 0)}%
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="empty-state">Data prakiraan belum tersedia.</p>
              )}

              <p className="map-note">
                Prakiraan cuaca bukan pengukuran curah hujan aktual di setiap kelurahan.
              </p>
            </section>

            <section className="info-panel">
              <h3 className="panel-heading">Data Curah Hujan</h3>

              {latestRain.length ? (
                <div className="data-list">
                  {latestRain.slice(0, 5).map((item, index) => (
                    <div className="data-row" key={`hujan-${index}`}>
                      <strong>
                        {item.nama_kelurahan ||
                          item.kelurahan ||
                          item.kode_wilayah ||
                          "Data hujan"}
                      </strong>
                      <div>
                        Nilai:{" "}
                        {formatAngka(
                          nilaiPertama(item, [
                            "nilai_mm", "hujan_mm", "curah_hujan_mm",
                            "nilai", "curah_hujan",
                          ])
                        )} mm
                      </div>
                      <div>
                        Tanggal:{" "}
                        {formatTanggal(
                          item.waktu_pengamatan ||
                            item.tanggal ||
                            item.waktu ||
                            item.datetime ||
                            item.waktu_analisis
                        )}
                      </div>
                      <div>Sumber: {item.sumber || item.metode || "Tidak diketahui"}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="empty-state">Belum ada data curah hujan.</p>
              )}
            </section>

            <section className="info-panel">
              <h3 className="panel-heading">Data Elevasi</h3>

              {selected && elevasiTerpilih ? (
                <>
                  <p><strong>Kelurahan:</strong> {selected.nama_kelurahan}</p>
                  <p>
                    <strong>Elevasi titik:</strong>{" "}
                    {formatAngka(
                      nilaiPertama(elevasiTerpilih, [
                        "elevasi_titik_m", "elevasi_m", "elevasi", "elevation",
                      ])
                    )} m
                  </p>
                  <p><strong>Sumber:</strong> {elevasiTerpilih.sumber || "Tidak diketahui"}</p>
                </>
              ) : elevasi.length ? (
                <div className="data-list">
                  {elevasi.slice(0, 5).map((item, index) => (
                    <div className="data-row" key={`elevasi-${index}`}>
                      <strong>
                        {item.nama_kelurahan ||
                          item.kelurahan ||
                          item.kode_wilayah ||
                          `Data elevasi ${index + 1}`}
                      </strong>
                      <div>
                        Elevasi:{" "}
                        {formatAngka(
                          nilaiPertama(item, [
                            "elevasi_titik_m", "elevasi_m", "elevasi", "elevation",
                          ])
                        )} m
                      </div>
                      <div>Sumber: {item.sumber || "Tidak diketahui"}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="empty-state">Belum ada data elevasi.</p>
              )}

              <p className="map-note">
                Elevasi ini merupakan titik representatif, bukan model elevasi seluruh permukaan kelurahan.
              </p>
            </section>
          </aside>
        </section>

        <footer className="app-footer">
          <p>
            WebGIS Risiko Banjir Makassar — informasi ini merupakan estimasi awal,
            bukan pengganti peringatan resmi instansi kebencanaan.
          </p>
        </footer>
      </main>
    </div>
  );
}
